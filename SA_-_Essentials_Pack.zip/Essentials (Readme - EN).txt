  __  __ _      __  __           _     
 |  \/  (_)    |  \/  |         | | 2023
 | \  / |___  _| \  / | ___   __| |___ 
 | |\/| | \ \/ / |\/| |/ _ \ / _` / __|
 | |  | | |>  <| |  | | (_) | (_| \__ \
 |_|  |_|_/_/\_\_|  |_|\___/ \__,_|___/
                                       

=======   MixMods.com.br   ======= - Best visualization with monospaced fonts, like "Consolas".


------- Instructions:

Extract ALL to your GTA SA folder.

If your GTA SA is Steam/RLG, downgrade it: https://www.mixmods.com.br/2021/09/primeiros-passos-para-montar-um-gta-modificado/#Downgrade


== Mods included in this pack (DD/MM/YY):
EXE 1.0 US Hoodlum + 4 GB largeaddress patch
Silent's ASI Loader v1.3
CLEO v4.4.4 (no dev files)
CLEO+ v1.1.5 (no dev files)
ModLoader v0.3.7
SilentPatch v1.1 Build 32 (re-release)
Widescreen Fix by ThirteenAG 09/27/18
Widescreen Fix HOR + Support v1.0.2 (recompiled by ThirteenAG)
Windowed Mode v1.11
Framerate Vigilante 10/08/21
CrashInfo v1.2
RepairGTA Build 5 14/08/23
RunDLL32 Fix
NoDEP


In the "(ESSENTIALS README)" folder it includes all readme files (IGNORE THE INSTALLATION INSTRUCTIONS IN THEM).
Also, a shortcut to the post of each mod for more informations (it's very important to read to learn what the mod does, possible problems etc)

The "(fix dependencies)" folder may not be necessary for you, but take a look, especially if you've formatted your PC recently.


There are still several important mods to install such as Open Limit Adjuster, MixSets etc.
BE SURE TO READ THIS PAGE:
https://www.mixmods.com.br/2021/09/primeiros-passos-para-montar-um-gta-modificado/
There are more important mods and good practices on how to mod your GTA.


Periodically, visit this page to see if we have released a new version of this pack with updated mods:
https://www.mixmods.com.br/2019/06/sa-essentials-pack/
It's very important to always have the latest versions of these mods to fix problems, have new features, be able to install new mods etc.


Originally Silent's ASI Loader comes with a "scripts" folder but few people install .asi in it, they prefer to install it in ModLoader to have better control.
If you want, just create a folder called "scripts" in the game folder and install the ASI mods in it.


If your PC is very weak, "Windowed Mode" may cause lag as it connects the game window to your desktop and therefore forces vsync. But it fixes bugs when closing and minimizing the game.



Pack: 14/08/23 (DD/MM/YY)
--------------------


====   MixMods.com.br                ====
====   fb.com/FamiliaMixMods         ====
====   youtube.com/JuniorDjjrMixMods ====

