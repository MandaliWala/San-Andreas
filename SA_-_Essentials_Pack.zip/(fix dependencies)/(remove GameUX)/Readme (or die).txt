  __  __ _      __  __           _     
 |  \/  (_)    |  \/  |         | | 2020
 | \  / |___  _| \  / | ___   __| |___ 
 | |\/| | \ \/ / |\/| |/ _ \ / _` / __|
 | |  | | |>  <| |  | | (_) | (_| \__ \
 |_|  |_|_/_/\_\_|  |_|\___/ \__,_|___/
                                       

=======   MixMods.com.br   ======= - Best visualization with monospaced fonts, like "Consolas".


------- Instructions:

GameUX.dll communicates for updates, which causes problems when trying to run an old game.

Attention: This will completely remove GameUX.dll and change compatibility registry.
           Looks like GameUX.dll isn't used on Windows 10, only on Windows 7 bellow, but it still exists.
           You still have the option of running .bat on Windows 10 to remove it anyway, it's safe.

Extract everything to a folder on your PC.

Run the file "gameux_delet.bat" IN ADMINISTRATOR MODE.
Check that there was no "access" denied message or anything.

Once everything is right, you can also run "GameUX_DisableShims.reg", just confirm.

Then, maybe you DON'T need "rundll32exefix.asi" anymore.


====   MixMods.com.br                ====
====   fb.com/FamiliaMixMods         ====
====   youtube.com/JuniorDjjrMixMods ====

