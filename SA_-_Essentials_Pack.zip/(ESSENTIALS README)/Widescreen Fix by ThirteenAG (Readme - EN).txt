  __  __ _      __  __           _     
 |  \/  (_)    |  \/  |         | | 2018
 | \  / |___  _| \  / | ___   __| |___ 
 | |\/| | \ \/ / |\/| |/ _ \ / _` / __|
 | |  | | |>  <| |  | | (_) | (_| \__ \
 |_|  |_|_/_/\_\_|  |_|\___/ \__,_|___/
                                       

=======   MixMods.com.br   ======= - Best visualization in Notepad with monospaced font, as "Consolas".


------- Instructions:

Extract the files to any folder inside Modloader folder. Or if you prefer to your "Scripts" folder or GTA SA directory.

-- Download the latest version of Modloader: MixMods.com.br/2015/01/SA-Modloader.html



 You can edit .ini file to configure things like hud size, force resolution, control fov etc.
 If you have artefacts on screen corners when driving in high speed, find "CarSpeedDependantFOV = 20.0" on .ini and change the 20.0 to about 30.0.



Version: 27/09/18
--------------------

Author: ThirteenAG


====   MixMods.com.br         ====
====   fb.com/FamiliaMixMods  ====

