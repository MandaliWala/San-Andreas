  __  __ _      __  __           _     
 |  \/  (_)    |  \/  |         | | 2018
 | \  / |___  _| \  / | ___   __| |___ 
 | |\/| | \ \/ / |\/| |/ _ \ / _` / __|
 | |  | | |>  <| |  | | (_) | (_| \__ \
 |_|  |_|_/_/\_\_|  |_|\___/ \__,_|___/
                                       

=======   MixMods.com.br   ======= - Best visualization in Notepad with monospaced font, as "Consolas".


------- Instructions:

= GTA SA:
Extract all to your game folder. If you prefer, the .asi to "scripts" folder.
 - Necessary Silent Asi Loader: MixMods.com.br/2013/02/silent-asi-loader.html
 - Necessary Crack 1.0 � voc� pode encontrar em: Miscellaneous-C.blogspot.com


= GTA III/VC:
Extract the .asi file to "scripts" folder" or your game folder (if didn't work, use the "scripts" folder), and the "modloader" folder to your game folder.
 - Necessary Ultimate ASI Loader: MixMods.com.br/2015/08/jogos-em-geral-universal-asi-loader.html
 - Necessary Crack 1.0 or 1.1 � voc� pode encontrar em: Miscellaneous-C.blogspot.com


To make sure that all worked, when entering in game it will create a .log file and .ini inside "modloader" folder.



--- Tips:
Read the file "Readme (ORIGINAL).txt" written by LINK/2012 itself.
Read the tutorial on how to use ModLoader written by me (Junior_Djjr): MixMods.com.br/2015/07/tutorial-dicas-tudo-sobre-mod-loader.html
A fast way to make a ModLoader folder don't be loaded is to put a dot and space on start of folder name. (for example ". mod")
The file "modloader\modloader.log" gives you all mods information being loaded (or not), as well as technical information about crashes that can be used here: MixMods.com.br/p/lista-de-crash-e-solucoes.html
Pause the game, go to "Options -> Mod Configurations" to install/desinstall mods in-game (take care with this).

 

Version: v0.3.7
--------------------

Author: LINK/2012

Thanks to:
ArtututuVidor$, Andryo, Junior_Djjr, JNRois12 (alpha tests)
Gramps and TJGM (emotional support)
Silent (additional support)
ThirteenAG (some pointers for III/VC)


====   MixMods.com.br         ====
====   fb.com/FamiliaMixMods  ====

