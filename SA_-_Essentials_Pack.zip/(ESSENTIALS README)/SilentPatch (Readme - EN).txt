  __  __ _      __  __           _     
 |  \/  (_)    |  \/  |         | | 2020
 | \  / |___  _| \  / | ___   __| |___ 
 | |\/| | \ \/ / |\/| |/ _ \ / _` / __|
 | |  | | |>  <| |  | | (_) | (_| \__ \
 |_|  |_|_/_/\_\_|  |_|\___/ \__,_|___/
                                       

=======   MixMods.com.br   ======= - Best visualization with monospaced font, as "Consolas".


------- Instructions:

Extract the "SilentPatch" folder to your Modloader folder. Or if you prefer to your GTA SA directory, or "scripts" folder.

-- Download the latest version of Modloader: MixMods.com.br/2015/01/SA-Modloader.html



 Inside .ini there are several informations and stuffs that you may want to enable/disable.

 Remember that Maverick and Skimmer comes with disabled rotor blur by default in .ini file, because the original model comes with bugged textures and doesn't work.
 If you want, download the fixed models: https://sharemods.com/71hnwbzkk0nu/RotorFix_for_SilentPatch.7z.html

 Full list of functions in english on "Readme (ORIGINAL).txt".
 Read "Readme (ORIGINAL).txt" if you want to install on Steam or RGL (Rockstar Games Launcher) version.
 


Version: v1.1 Build 32 (re-release)
--------------------

Author: Silent

Credits:
DK22Pac - 'dark lights' fix, coloured detached components fix, mirrors multisampling fix, help with shaders, technical support
NTAuthority - moonphases code, DirectPlay dependency removal code, technical support

People who helped to identify issues, tested the patch or were generally supportive:
aap, Ash_735, Blackbird88, gamerzworld, iFarbod, Inadequate, LonesomeRider, mirh, Nick007J, Reyks, spaceeinstein, Tomasak


====   MixMods.com.br                ====
====   fb.com/FamiliaMixMods         ====
====   youtube.com/JuniorDjjrMixMods ====

