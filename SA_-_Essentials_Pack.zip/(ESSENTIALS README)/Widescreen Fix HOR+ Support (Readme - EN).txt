  __  __ _      __  __           _     
 |  \/  (_)    |  \/  |         | | 2018
 | \  / |___  _| \  / | ___   __| |___ 
 | |\/| | \ \/ / |\/| |/ _ \ / _` / __|
 | |  | | |>  <| |  | | (_) | (_| \__ \
 |_|  |_|_/_/\_\_|  |_|\___/ \__,_|___/
                                       

=======   MixMods.com.br   ======= - Best visualization in Notepad with monospaced font, as "Consolas".


------- Instructions:

Extract the files to any folder inside Modloader folder. Or if you prefer to your "Scripts" folder or GTA SA directory.

-- Download the latest version of Modloader: MixMods.com.br/2015/01/SA-Modloader.html



Version: 1.0.2 - Recompiled by ThirteenAG
--------------------

Author: Wesser
Thanks to: Silent and gta_sa.idb contributors


====   MixMods.com.br         ====
====   fb.com/FamiliaMixMods  ====

